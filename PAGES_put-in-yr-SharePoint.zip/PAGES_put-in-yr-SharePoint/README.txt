These are the companion files to my DSG demo repository at https://github.com/hlxsites/dsg .
These instructions assume you are planning to use OneDrive for the pages, but Google Drive can be easily used instead.

To set up your own playground, 

- Click "Fork" on the Github page (https://github.com/hlxsites/dsg) to copy the code to your own github account

- Put the contents of this zip folder into a new "dsg" folder in your Adobe OneDrive account, which is your 'personal' Sharepoint.

- In your new Git repo, change the fstab.yaml mountpoint to point to your OneDrive folder. In my case, I used the below:
(Mind the indention of the address line, this is required for proper yaml formatting!)

mountpoints:
  /: https://adobe-my.sharepoint.com/personal/chelms_adobe_com/Documents/P_Franklin/dsg


- In your Sidekick Chrome extension, the Repository URL field should point to the "main" branch of your forked repo, example:
https://github.com/<your-username>/dsg/tree/main

- The extension should pick up your personal Sharepoint address automatically, 
but you can check/edit by right-clicking on the extention's icon and choosing "options" to edit manually.

-------- TIPS ------------

- Create your own OneDrive folder under '/drafts' if you want to test out new pages or content changes.

- However, the "nav" and "footer" locations are hard-coded in their block javascript code, so either replace the docx with your own versions, or edit the paths in the javascript:
https://github.com/hlxsites/dsg/blob/main/blocks/footer/footer.js#L24
https://github.com/hlxsites/dsg/blob/main/blocks/header/header.js#L97

- Don't forget to 'preview' the nav, footer, and the /fragments docx files once so they are added to the Content Bus before attempting to preview "index.docx" or you'll get errors.

- The preview flow looks like this: Word / Google doc --> markdown (.md) --> plain html (.plain.html) --> final html (with css, js etc..) 

- Using 'Preview' via sidekick is the only way to view your new page and all changes going forward -- this sends it to Content Bus 
(but not the CDN yet, that's only when published for .live. For a deep dive into the architecture, see https://github.com/adobe/helix-home/blob/main/docs/architecture.md)

- You can append `.plain.html` to any page to see the bare bones DOM before any JS or CSS is applied. 
For example, https://main--dsg--hlxsites.hlx.page/ can be viewed as https://main--dsg--hlxsites.hlx.page/index.plain.html

- On any Franklin webpage you can append  `?view-doc-source=true` to view the document without having access to the sharepoint/googledoc, 
OR right-click on the Sidekick extension icon and "View document source".